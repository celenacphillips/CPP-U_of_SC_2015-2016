#include "editdistance.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Class 'EditDistance' for the edit distance computation.
 *
 * Author: Duncan A. Buell
 * Date last modified: 8 August 2016
**/

/******************************************************************************
 * Constructor
**/
EditDistance::EditDistance() {
}

/******************************************************************************
 * Destructor
**/
EditDistance::~EditDistance() {
}

/******************************************************************************
 * Accessors and Mutators
**/

/******************************************************************************
 * General functions.
**/

/******************************************************************************
 * Function 'ComputeDistances'.
 * This function computes the distances between the two sentences.
 *
**/
void EditDistance::ComputeDistances()
{
}

/******************************************************************************
 * Function 'Initialize'.
**/
void EditDistance::Initialize(Scanner& scanner)
{
}

/******************************************************************************
 * Function 'ToString'.
 * Returns:
 *   a 'string' of the two sentences and the matrix with the edit distances
**/
string EditDistance::ToString()
{
}
