#include "domino.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Class 'Domino' for a single domino.
 *
 * Author: Duncan A. Buell
 * Date last modified: 6 August 2016
**/

/******************************************************************************
 * Constructor
**/
Domino::Domino() {
}

/******************************************************************************
 * Constructor with data supplied
**/
Domino::Domino(int left, int right) {
}

/******************************************************************************
 * Destructor
**/
Domino::~Domino() {
}

/******************************************************************************
 * Accessors and Mutators
**/

/******************************************************************************
 * Accessor 'GetLeft'.
 *
 * Returns:
 *   the left of the numbers on the domino 
**/
int Domino::GetLeft() const {
}

/******************************************************************************
 * Accessor 'GetRight'.
 *
 * Returns:
 *   the right of the numbers on the domino 
**/
int Domino::GetRight() const {
}

/******************************************************************************
 * Accessor 'HasBeenPlayed'.
 *
 * Returns:
 *   the boolean value of 'played_'
**/
bool Domino::HasBeenPlayed() const {
}

/******************************************************************************
 * Accessor 'WasDealt'.
 *
 * Returns:
 *   the boolean value of 'dealt'
**/
bool Domino::WasDealt() const {
}

/******************************************************************************
 * Mutator 'SetDealt'.
 *
 * Parameters:
 *   the boolean value to be set
**/
void Domino::SetDealt(bool value) {
}

/******************************************************************************
 * Mutator 'SetPlayed'.
 *
 * Parameters:
 *   the boolean value to be set
**/
void Domino::SetPlayed(bool value) {
}

/******************************************************************************
 * General functions.
**/
/******************************************************************************
 * Function 'FlipEnds' to flip a domino end for end.
**/
void Domino::FlipEnds() {
}

/******************************************************************************
 * Function 'ToString'.
 * This returns the 'played_' as well as the left and right numbers.
**/
string Domino::ToString() const {
  return s;
}
