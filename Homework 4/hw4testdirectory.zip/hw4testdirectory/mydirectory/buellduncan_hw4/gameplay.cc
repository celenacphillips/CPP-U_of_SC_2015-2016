#include "gameplay.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Class 'GamePlay' for playing part of a dominos game.
 *
 * Author: Duncan A. Buell
 * Date last modified: 6 August 2016
**/

/******************************************************************************
 * Constructor
**/
GamePlay::GamePlay() {
}

/******************************************************************************
 * Destructor
**/
GamePlay::~GamePlay() {
}

/******************************************************************************
 * Accessors and Mutators
**/

/******************************************************************************
 * General functions.
**/

/******************************************************************************
 * Function 'DealDominos'.
 *
 * We run a loop to print out the first ten random numbers just to be able to
 * check that we are getting the same sequence of numbers.
 *
 * Then we loop until we get 'kHandsize' number of dominos.
 *
 *
 * Parameters:
 *   out_stream - the output stream to which to write
**/
void GamePlay::DealDominos(ofstream& out_stream, int seed) {
#ifdef EBUG
  Utils::log_stream << "enter DealDominos\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave DealDominos\n"; 
#endif
}

/******************************************************************************
 * Function 'ExtendSeq'.
 * This function extends the sequence.
 *
 * Parameters:
 *   from - the number to be matched from unplayed dominos
 *   seq - the current sequence of played dominos
 *   level - the level of recursion on entry to this function
 *   out_stream - the output stream to which to write
**/
void GamePlay::ExtendSeq(int from, const vector<Domino>& seq, int level,
                         ofstream& out_stream) {
#ifdef EBUG
  Utils::log_stream << "enter extendSeq\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave ExtendSeq\n"; 
#endif
}

/******************************************************************************
 * Function 'FindLongestSeq'.
 *
 * Parameters:
 *   out_stream - the output stream to which to write
**/
void GamePlay::FindLongestSeq(ofstream& out_stream) {

#ifdef EBUG
  Utils::log_stream << "enter FindLongestSeq\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave FindLongestSeq\n"; 
#endif
}

/******************************************************************************
 * Function 'Initialize'.
**/
void GamePlay::Initialize() {
#ifdef EBUG
  Utils::log_stream << "enter Initialize\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave initialize\n"; 
#endif
}

/******************************************************************************
 * Function 'ToString'.
 * This function dumps the 'vector' of all dominos to a 'string' and returns it.
 *
 * Returns:
 *   the 'ToString' of the data in the class
**/
string GamePlay::ToString() const
{
#ifdef EBUG
  Utils::log_stream << "enter ToString\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave ToString\n"; 
#endif
  return s;
}

/******************************************************************************
 * Function 'ToStringSeq'.
 * This function dumps the 'mySeq' data to a 'string' and returns it, with a
 * label for helping know what is being dumped.
 *
 * Returns:
 *   the 'ToString' of the 'vector' of dominoes passed in to the function
**/
string GamePlay::ToStringSeq(string label, const vector<Domino>& the_seq) const {
  vector<Domino>::const_iterator iter;

#ifdef EBUG
  Utils::log_stream << "enter ToStringSeq\n"; 
#endif

#ifdef EBUG
  Utils::log_stream << "leave ToStringSeq\n"; 
#endif
  return s;
}
