Do your programming in the 'mydirectory' directory, in a directory
loginname_hwxx.  That is, since my login id is 'buell', I would do
all my programming in the directory 'mydirectory/buell_hwxx'.
(Replace the 'xx' with the appropriate TWO-DIGIT sequence number.)

Run the script zaZipUpScript.txt to tar and gzip your directory
and copy it to the 'assignment' directory.

Run the script zbFileCopyScript.txt to create directory 'testdirectory'
and unzip and untar your submission from 'assignment' into 'testdirectory'.

Run the script zcCompileScript.txt to compile all the programs in
'testdirectory'.

Run the script zdExecuteScript.txt to execute all the programs that
were compiled in the previous step.

If this works, you should have the appropriate output files in your
directory. For me, with login id 'buell', the output should be in
'testdirectory/buell_hw01/zoutputxx.txt'.

