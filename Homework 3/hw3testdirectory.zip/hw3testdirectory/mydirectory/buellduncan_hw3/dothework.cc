#include "dothework.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Homework 3 'DoTheWork' application class.
 *
 * Author: Duncan A. Buell
 * Date last modified: 5 August 2016
**/

static const string kTag = "DoTheWork: ";

/******************************************************************************
 * Constructor
**/
DoTheWork::DoTheWork() {
}

/******************************************************************************
 * Destructor
**/
DoTheWork::~DoTheWork() {
}

/******************************************************************************
 * Accessors and Mutators
**/

/******************************************************************************
 * General functions.
**/

/******************************************************************************
 * Function 'ReadData'.
 * We read data from the input stream, record by record, and push it into
 * the 'vector' named 'the_data_'.
 *
 * NOTE: We are assuming that if there is any data, there is an entire record,
 * so we can just read the entire record as a unit. 
 *
 * Parameter:
 *   data_stream -- the input data stream
**/
void DoTheWork::ReadData(Scanner& data_stream)
{
  ScanLine scanline;
#ifdef EBUG
  cout << kTag << "enter ReadData\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave ReadData\n"; 
#endif
} // void DoTheWork::ReadData(Scanner& data_stream)

/******************************************************************************
 * Function 'SortRecords'.
 * We sort the records either by 'surname_' or by 'phone_number_'.
 *
 * This is a simple bubble sort.
 *
 * Parameter:
 *   how_sort -- either the string 'name' or 'number'
**/
void DoTheWork::SortRecords(string how_sort) {
#ifdef EBUG
  cout << kTag << "enter SortRecords\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave SortRecords\n"; 
#endif
} // void DoTheWork::SortRecords(string howSort)

/******************************************************************************
 * Swap function, swaps subscripts 'i' and 'j' data in 'the_data_'
**/
void DoTheWork::Swap(int i, int j) {
} // void Swap(int i, int j) {

/******************************************************************************
 * Function 'ToString'.
 * This is the usual 'ToString'. We output the 'vector' of 'Record'
 * instances without regard to the order.
 *
 * Returns:
 *   a formatted 'string' version of the 'vector' of records
**/
string DoTheWork::ToString() {
  string s = "";
#ifdef EBUG
  cout << kTag << "enter ToString\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave ToString\n"; 
#endif
  return s;
} // void DoTheWork::ToString()

/******************************************************************************
 * Function 'ToStringByName'.
 *
 * First we sort the data by name, then we call the regular 'ToString'.
 *
 * Returns:
 *   a string of the records output in sorted order by name
**/
string DoTheWork::ToStringByName() {
  string s = "";
#ifdef EBUG
  cout << kTag << "enter ToStringByName\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave ToStringByName\n"; 
#endif

  return this->ToString();
} // void DoTheWork::ToStringByName()

/******************************************************************************
 * Function 'ToStringByNumber'.
 *
 * First we sort the data by number, then we call the regular 'ToString'.
 *
 * Returns:
 *   a string of the records output in sorted order by number
**/
string DoTheWork::ToStringByNumber() {
  string s = "";
#ifdef EBUG
  cout << kTag << "enter ToStringByNumber\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave ToStringByNumber\n"; 
#endif

  return this->ToString();
} // void DoTheWork::ToStringByNumber()
