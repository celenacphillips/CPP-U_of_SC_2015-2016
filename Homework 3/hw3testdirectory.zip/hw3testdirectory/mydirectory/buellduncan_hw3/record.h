/****************************************************************
 * Header file for the phone book record for homework 3.
 *
 * Author/copyright:  Duncan Buell
 * Date: 5 August 2016
 *
**/

#ifndef RECORD_H
#define RECORD_H

#include <iostream>
using namespace std;

#include "../../Utilities/scanner.h"
#include "../../Utilities/scanline.h"

class Record
{
public:
 Record();
 virtual ~Record();

 int CompareName(Record that);
 int CompareNumber(Record that);
 string GetSurname();
 string GetPhoneNumber();
 void ReadData(Scanner& data_stream);
 string ToString();

private:
 string forename_ = "dummyforename";
 string othername_ = "dummyothername";
 string surname_ = "dummysurname";
 string phone_number_ = "dummyphonenumber";
};

#endif
