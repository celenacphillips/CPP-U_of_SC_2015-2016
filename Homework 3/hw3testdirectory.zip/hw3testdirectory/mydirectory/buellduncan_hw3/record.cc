#include "record.h"

/******************************************************************************
 *3456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
 * Class 'Record' for a single phone book record in a tree.
 *
 * Author: Duncan A. Buell
 * Date last modified: 5 August 2016
**/

static const string kTag = "Record: ";

/******************************************************************************
 * Constructor
**/
Record::Record() {
}

/******************************************************************************
 * Destructor
**/
Record::~Record() {
}

/******************************************************************************
 * Accessors and Mutators
**/
/******************************************************************************
 * Accessor for 'phone_number_'
 *
 * Returns:
 *   'phone_number_'
**/
string Record::GetPhoneNumber() {
}

/******************************************************************************
 * Accessor for 'surname_'
 *
 * Returns:
 *   'surname_'
**/
string Record::GetSurname() {
}

/******************************************************************************
 * General functions.
**/

/******************************************************************************
 * Comparison function for 'phone_number_'
 *
 * Parameter:
 *   that - the 'Record' to compare 'this' against
 *
 * Returns:
 *   negative number if 'this' is less than 'that'
 *   zero number if 'this' is equal to 'that'
 *   positive number if 'this' is greater than 'that'
**/
int Record::CompareNumber(Record that) {
}

/******************************************************************************
 * Comparison function for 'surname_'
 *
 * Parameter:
 *   that - the 'Record' to compare 'this' against
 *
 * Returns:
 *   true if 'this' Record 'surname_' is less than 'that' Record 'surname_'
**/
int Record::CompareName(Record that) {
}

/******************************************************************************
 * Function 'ReadData'.
 *
 * We read the distinct lines of input data. Each line is a label
 * of the item, the number bought, and the cost per item.
 *
 * THERE IS NO BULLETPROOFING OF THE INPUT DATA.
 *
 * Parameter:
 *   data_stream - the opened 'Scanner' to read from
**/
void Record::ReadData(Scanner& data_stream) {
  vector<string> tokens;
  ScanLine scanline;

#ifdef EBUG
  cout << kTag << "enter ReadData\n"; 
#endif

#ifdef EBUG
  cout << kTag << "leave readData\n"; 
#endif

} // void Record::readData(Scanner& data_stream)

/******************************************************************************
 * Function 'ToString'.
 * This is the usual 'ToString' that returns the formatted data in the class.
**/
string Record::ToString() {
  string s = "";

  return s;
} // void Record::ToString()
