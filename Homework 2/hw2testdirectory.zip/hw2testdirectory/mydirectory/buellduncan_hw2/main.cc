#include "main.h"

/*******************************************************************************
 * 45678901234567890123456789012345678901234567890123456789012345678901234567890
 * Main program for Homework 2.
 *
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Used with permission and modified by: Jane Random Hacker
 * Date: 4 August 2016
**/

int ComputePayoffInMonths(double amount, double monthly_payment,
                          double yearly_rate);

/*******************************************************************************
**/
int main( ) {

  return 0;
} // int main( )

/*******************************************************************************
**/
int ComputePayoffInMonths(double amount, double monthly_payment,
                           double yearly_rate) {
  return month;
} // int ComputePayoffInMonths(double amount, double monthly_payment,


